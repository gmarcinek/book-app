from .simple import SimpleNER

__all__ = [
    'SimpleNER'
]