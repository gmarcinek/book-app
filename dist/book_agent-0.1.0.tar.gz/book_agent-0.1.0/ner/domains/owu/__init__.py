from .owu import OwuNER

__all__ = [
    'OwuNER',
]