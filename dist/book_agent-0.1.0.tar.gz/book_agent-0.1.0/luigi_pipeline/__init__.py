"""
TOC-based document processing pipeline
"""

__version__ = "0.1.0"