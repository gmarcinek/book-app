import streamlit as st

def main():
    st.title("Surya GUI")
    # Dodaj interfejs tutaj, np. file uploader, preview itp.

if __name__ == "__main__":
    main()