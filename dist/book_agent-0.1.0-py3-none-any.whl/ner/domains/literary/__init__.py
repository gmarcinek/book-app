from .literary import LiteraryNER

__all__ = [
    'LiteraryNER',
]